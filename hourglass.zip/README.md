# hourglass
shows time as %, a browser extension <br>
<img width="333" alt="image" src="https://github.com/user-attachments/assets/48db1cde-b890-4034-9799-96947dcf7371" />
